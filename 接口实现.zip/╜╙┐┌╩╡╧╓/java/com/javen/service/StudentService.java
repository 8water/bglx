package com.javen.service;

import java.util.List;

import com.javen.model.Page;
import com.javen.model.Student;

public interface StudentService {
	
	public int count();
	
	public int insert(Student student);
	
	public int updateByPrimaryKey(Student student);
	
	public int deleteByPrimaryKey(int id);
	
	public int deleteByIds(List<Integer> ids);
	
	public List<Student> selectAll(Page page);
	
	public List<Student> selectBySex(String student_sex);
	
	public List<Student> selectByName(String student_name);
}
