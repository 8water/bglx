package com.javen.service;

import java.util.List;

import com.javen.model.Class;
import com.javen.model.Page;

public interface ClassService{
	
	public int count();
	
	
	public int insert(Class class1);
	
	public int updateByPrimaryKey(Class class1);
	
	public int deleteByPrimaryKey(int id);
	
	//public int deleteAll();
	
	public Class selectByPrimaryKey(int id);
	
	public List<Class> selectAll(Page page);
}
