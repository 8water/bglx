package com.javen.service;

import java.util.List;

import com.javen.model.Page;
import com.javen.model.Teacher;

public interface TeacherService {
	
	public int count();
	
	public int insert(Teacher teacher);
	
	public int updateByPrimaryKey(Teacher teacher);
	
	public int deleteByPrimaryKey(int id);
	
	//public int deleteAll();
	
	public Teacher selectByPrimaryKey(int id);
	
	public List<Teacher> selectAll(Page page);
}
