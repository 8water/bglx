package com.javen.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javen.dao.StudentDao;
import com.javen.model.Page;
import com.javen.model.Student;
import com.javen.service.StudentService;

@Service
public class StudentServicelmpl implements StudentService{
	@Autowired
	private StudentDao studentDao;
	
	public int count() {
		return studentDao.count();
	}
	
	public int insert(Student student) {
		return studentDao.insert(student);
	}
	
	public int updateByPrimaryKey(Student student) {
		return studentDao.updateByPrimaryKey(student);
	}
	
	public int deleteByPrimaryKey(int id) {
		return studentDao.deleteByPrimaryKey(id);
	}
	
	public int deleteByIds(List<Integer> ids) {
		return studentDao.deleteByIds(ids);
	}
	
	public List<Student> selectAll(Page page) {
		return studentDao.selectAll(page);
	}
	
	public List<Student> selectBySex(String student_sex){
		return studentDao.selectBySex(student_sex);
	}
	
	public List<Student> selectByName(String student_name){
		return studentDao.selectByName(student_name);
	}
}
