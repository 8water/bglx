package com.javen.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javen.dao.TeacherDao;
import com.javen.model.Page;
import com.javen.model.Teacher;
import com.javen.service.TeacherService;

@Service
public class TeacherServicelmpl implements TeacherService{
	@Autowired
	private TeacherDao teacherDao;
	
	public int count() {
		return teacherDao.count();
	}
	
	
	public int insert(Teacher teacher) {
		return teacherDao.insert(teacher);
	}
	
	public int updateByPrimaryKey(Teacher teacher) {
		return teacherDao.updateByPrimaryKey(teacher);
	}
	
	public int deleteByPrimaryKey(int id) {
		return teacherDao.deleteByPrimaryKey(id);
	}
	
	//public int deleteAll() {
	//	return studentDao.deleteAll();
	//}
	
	public Teacher selectByPrimaryKey(int id) {
		return teacherDao.selectByPrimaryKey(id);
	}
	
	public List<Teacher> selectAll(Page page) {
		return teacherDao.selectAll(page);
	}

}
