package com.javen.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javen.dao.ClassDao;
import com.javen.model.Class;
import com.javen.model.Page;
import com.javen.service.ClassService;

@Service
public class ClassServicelmpl  implements ClassService{
	@Autowired
	private ClassDao classDao;
	
	public int count() {
		return classDao.count();
	}
	
	
	public int insert(Class class1) {
		return classDao.insert(class1);
	}
	
	public int updateByPrimaryKey(Class class1) {
		return classDao.updateByPrimaryKey(class1);
	}
	
	public int deleteByPrimaryKey(int id) {
		return classDao.deleteByPrimaryKey(id);
	}
	
	//public int deleteAll() {
	//	return studentDao.deleteAll();
	//}
	
	public Class selectByPrimaryKey(int id) {
		return classDao.selectByPrimaryKey(id);
	}
	
	public List<Class> selectAll(Page page) {
		return classDao.selectAll(page);
	}
}
