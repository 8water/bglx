package com.javen.dao;

import java.util.List;

import com.javen.model.Class;
import com.javen.model.Page;

public interface ClassDao {
	
	public int count();
	
	public int insert(Class class1);
	
	public int updateByPrimaryKey(Class class1);
	
	public int deleteByPrimaryKey(int id);
	
	//public int deleteAll();
	
	public List<Class> selectAll(Page page);
	
	public Class selectByPrimaryKey(int id);
}
