package com.javen.dao;

import java.util.List;

import com.javen.model.Page;
import com.javen.model.Teacher;

public interface TeacherDao {
	
	public int count();
	
	public int insert(Teacher teacher);
	
	public int updateByPrimaryKey(Teacher teacher);
	
	public int deleteByPrimaryKey(int id);
	
	//public int deleteAll();
	
	public List<Teacher> selectAll(Page page);
	
	public Teacher selectByPrimaryKey(int id);

	
}
