package com.javen.model;

import java.util.List;

public class Class {
	private Integer id;
	private String class_name;
	private String class_grade;
	private String class_remark;
	private String class_date;
	private List<Student> studentList; 
	private List<Teacher> teacherList;
	
	
	public List<Student> getStudent() {
		return studentList;
	}
	public void setStudent(List<Student> student) {
		this.studentList = student;
	}
	public List<Teacher> getTeacher() {
		return teacherList;
	}
	public void setTeacher(List<Teacher> teacher) {
		this.teacherList = teacher;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getClass_name() {
		return class_name;
	}
	public void setClass_name(String class_name) {
		this.class_name = class_name;
	}
	public String getClass_grade() {
		return class_grade;
	}
	public void setClass_grade(String class_grade) {
		this.class_grade = class_grade;
	}
	public String getClass_remark() {
		return class_remark;
	}
	public void setClass_remark(String class_remark) {
		this.class_remark = class_remark;
	}
	public String getClass_date() {
		return class_date;
	}
	public void setClass_date(String class_date) {
		this.class_date = class_date;
	}
	@Override
	public String toString() {
		return "Class [id=" + id + ", class_name=" + class_name + ", class_grade=" + class_grade + ", class_remark="
				+ class_remark + ", class_date=" + class_date + ", student=" + studentList + ", teacher=" + teacherList + "]";
	}
	
}
