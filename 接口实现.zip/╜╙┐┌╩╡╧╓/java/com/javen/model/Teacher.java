package com.javen.model;

import java.util.List;

public class Teacher {
	private Integer id;
	private String teacher_name;
	private String teacher_sex;
	private String teacher_number;
	private String teacher_date;
	
	//关联集合
	private List<Class> classList;
	
	public List<Class> getClassList() {
		return classList;
	}
	public void setClassList(List<Class> classList) {
		this.classList = classList;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getTeacher_name() {
		return teacher_name;
	}
	public void setTeacher_name(String teacher_name) {
		this.teacher_name = teacher_name;
	}
	public String getTeacher_sex() {
		return teacher_sex;
	}
	public void setTeacher_sex(String teacher_sex) {
		this.teacher_sex = teacher_sex;
	}
	public String getTeacher_number() {
		return teacher_number;
	}
	public void setTeacher_number(String teacher_number) {
		this.teacher_number = teacher_number;
	}
	public String getTeacher_date() {
		return teacher_date;
	}
	public void setTeacher_date(String teacher_date) {
		this.teacher_date = teacher_date;
	}
	@Override
	public String toString() {
		return "Teacher [id=" + id + ", teacher_name=" + teacher_name + ", teacher_sex=" + teacher_sex
				+ ", teacher_number=" + teacher_number + ", teacher_date=" + teacher_date + ", class1=" + classList + "]";
	}
	
}
