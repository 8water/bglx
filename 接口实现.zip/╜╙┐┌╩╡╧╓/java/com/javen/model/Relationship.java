package com.javen.model;

public class Relationship {
	private Integer id;
	private Integer teacher_id;
	private Integer class_id;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getTeacher_id() {
		return teacher_id;
	}
	public void setTeacher_id(Integer teacher_id) {
		this.teacher_id = teacher_id;
	}
	public Integer getClass_id() {
		return class_id;
	}
	public void setClass_id(Integer class_id) {
		this.class_id = class_id;
	}
	@Override
	public String toString() {
		return "Relationship [id=" + id + ", teacher_id=" + teacher_id + ", class_id=" + class_id + "]";
	}
	
}
