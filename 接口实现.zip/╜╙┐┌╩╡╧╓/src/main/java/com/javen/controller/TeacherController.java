package com.javen.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.xml.transform.Source;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;  
import org.springframework.ui.Model;  
import org.springframework.web.bind.annotation.RequestMapping;  
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSONObject;
import com.javan.util.ObjtoLayJson;
import com.javen.model.Login;
import com.javen.model.Page;
import com.javen.model.Teacher;
import com.javen.service.ILoginService;
import com.javen.service.TeacherService;

@Controller  //返回指定页面  ajax 不能接受到页面的返回 ，所以说
@RequestMapping("/teacher") 
public class TeacherController {  
	
	private static Logger log=LoggerFactory.getLogger(LoginController.class);
	
	@Autowired 
	private TeacherService teacherService;     
    
    // /user/test?id=1
    @RequestMapping(value="/test", method=RequestMethod.GET)  
    public String test(HttpServletRequest request,Model model){  
        return "back"; 
    }
    
    @ResponseBody
    @RequestMapping(value="/count", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")  
    public String count(HttpServletRequest request) throws Exception{  
    	
    	int count  = teacherService.count();
    	System.out.println(count);
    	String data = "{\"count\":\""+count+"\"}";
        return data;    
    }
    
    //返回字符串
    @ResponseBody
    @RequestMapping(value="/selectByPrimaryKey", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")  
    public String selectByPrimaryKeyd(HttpServletRequest request) throws Exception{  
    	String  idString = request.getParameter("id");
    	Integer idInteger = Integer.valueOf(idString);
    	Teacher teacher = teacherService.selectByPrimaryKey(idInteger);
    	System.out.println(teacher.toString());
    	String[] colums = {"id","teacher_name","teacher_sex","teacher_number","teacher_date"};
    	String data = ObjtoLayJson.toJson(teacher, colums);
    	System.out.println(data);
        return data;    
    }
    
  //返回字符串
    @ResponseBody
    @RequestMapping(value="/selectAll", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")  
    public String selectAll(HttpServletRequest request) throws Exception{  	
    	request.setCharacterEncoding("utf-8");  
    	String pageString = request.getParameter("page");
    	String limitString = request.getParameter("limit");
    	Integer pageInteger = Integer.valueOf(pageString);
    	Integer limitInteger = Integer.valueOf(limitString);
    	
    	
    	Page page = new Page();
    	page.setOffset((pageInteger-1)*limitInteger);
    	page.setLimit(limitInteger);
    	System.out.println(page.getOffset() + " "+page.getLimit());
    	
    	List<Teacher> teacher = teacherService.selectAll(page);
    	System.out.println(teacher);
    	String[] colums = {"id","teacher_name","teacher_sex","teacher_number","teacher_date","classList"};
    	String data = ObjtoLayJson.ListtoJson(teacher, colums);
    	System.out.println(data);
        return data; 
    }
   
    
    @ResponseBody
    @RequestMapping(value="/insert", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")  
    public String insert(HttpServletRequest request) {
    	
    	String teacher_name = request.getParameter("teacher_name");
    	String teacher_sex = request.getParameter("teacher_sex");
    	String teacher_number = request.getParameter("teacher_number");
    	String teacher_date = request.getParameter("teacher_date");
    	
    	Teacher teacher = new Teacher();
    	teacher.setTeacher_name(teacher_name);
    	teacher.setTeacher_sex(teacher_sex);
    	teacher.setTeacher_number(teacher_number);
    	teacher.setTeacher_date(teacher_date);
    	
    	teacherService.insert(teacher);
    
    	//给前台返回的东西
    	String data = "{\"data\":\"插入成功\"}"; 
        return data; 
    }
    
    @ResponseBody
    @RequestMapping(value="/updateByPrimaryKey", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")  
    public String updateByPrimaryKey(HttpServletRequest request) {
    	
    	String idString = request.getParameter("id");
    	String teacher_name = request.getParameter("teacher_name");
    	String teacher_sex = request.getParameter("teacher_sex");
    	String teacher_number = request.getParameter("teacher_number");
    	String teacher_date = request.getParameter("teacher_date");
    	Integer idInteger = Integer.valueOf(idString);
    	
    	Teacher teacher = new Teacher();
    	teacher.setId(idInteger);
    	teacher.setTeacher_name(teacher_name);
    	teacher.setTeacher_sex(teacher_sex);
    	teacher.setTeacher_number(teacher_number);
    	teacher.setTeacher_date(teacher_date);
    	
    	teacherService.updateByPrimaryKey(teacher);
    	
    	
    	//给前台返回的东西
    	String data = "{\"data\":\"修改成功\"}"; 
        return data; 
    }
    
    @ResponseBody
    @RequestMapping(value="/deleteByPrimaryKey", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")  
    public String deleteByPrimaryKey(HttpServletRequest request) {
    	String  idString = request.getParameter("id");
    	Integer idInteger = Integer.valueOf(idString);
    	
    	teacherService.deleteByPrimaryKey(idInteger);
    	String data = "{\"data\":\"删除成功\"}"; 
        return data; 
    }
    
}  