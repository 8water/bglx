package com.javen.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.xml.transform.ErrorListener;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.URIResolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cglib.core.CollectionUtils;
import org.springframework.stereotype.Controller;  
import org.springframework.ui.Model;  
import org.springframework.web.bind.annotation.RequestMapping;  
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSONObject;
import com.javan.util.ObjtoLayJson;
import com.javen.model.Login;
import com.javen.model.Page;
import com.javen.model.Student;
import com.javen.service.ILoginService;
import com.javen.service.StudentService;

@Controller  //返回指定页面  ajax 不能接受到页面的返回 ，所以说
@RequestMapping("/student") 
public class StudentController {  
	
	private static Logger log=LoggerFactory.getLogger(LoginController.class);
	
	@Autowired  
	private StudentService studentService;     
    
    // /user/test?id=1
    @RequestMapping(value="/test", method=RequestMethod.GET)  
    public String test(HttpServletRequest request,Model model){  
        return "back"; 
    }
    
	
    @ResponseBody
    @RequestMapping(value="/count", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")  
    public String count(HttpServletRequest request) throws Exception{  
    	
    	int count  = studentService.count();
    	System.out.println(count);
    	String data = "{\"count\":\""+count+"\"}";
        return data;    
    }
    
    @ResponseBody//姓名查询是模糊查询
    @RequestMapping(value="/selectByName", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")  
    public String selectByName(HttpServletRequest request) throws Exception{  
    	String  student_name = request.getParameter("student_name");
    	System.out.println(student_name);
    	List<Student> student = studentService.selectByName(student_name);
    	String[] colums = {"id","class_id","student_name","student_number","student_sex","student_class","student_date"};
    	String data = ObjtoLayJson.ListtoJson(student, colums);//返回的是集合
    	System.out.println(data);
        return data;    
    }
    
    @ResponseBody//性别查询不是模糊查询
    @RequestMapping(value="/selectBySex", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")  
    public String selectBySex(HttpServletRequest request) throws Exception{  
    	String  student_sex = request.getParameter("student_sex");
    	List<Student> student = studentService.selectBySex(student_sex);
    	String[] colums = {"id","class_id","student_name","student_number","student_sex","student_class","student_date"};
    	String data = ObjtoLayJson.ListtoJson(student, colums);//返回的是集合
    	System.out.println(data);
        return data;    
    }
    
  //返回字符串
    @ResponseBody
    @RequestMapping(value="/selectAll", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")  
    public String selectAll(HttpServletRequest request) throws Exception{  	
    	request.setCharacterEncoding("utf-8");  
    	String pageString = request.getParameter("page");
    	String limitString = request.getParameter("limit");
    	Integer pageInteger = Integer.valueOf(pageString);
    	Integer limitInteger = Integer.valueOf(limitString);
    	
    	
    	
    	Page page = new Page();
    	page.setOffset((pageInteger-1)*limitInteger);
    	page.setLimit(limitInteger);
    	System.out.println(page.getOffset() + " "+page.getLimit());
    	
    	List<Student> student = studentService.selectAll(page);
    	System.out.println(student);
    	String[] colums = {"id","class_id","student_name","student_number","student_sex","student_class","student_date","class1"};
    	String data = ObjtoLayJson.ListtoJson(student, colums);
    	System.out.println(data);
    	//String data = "{\"message\":\"查询成功！\"}";
        return data; 
    }
   
    
    @ResponseBody
    @RequestMapping(value="/insert", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")  
    public String insert(HttpServletRequest request) {
    	
    	String student_name = request.getParameter("student_name");
    	String student_number = request.getParameter("student_number");
    	String student_sex = request.getParameter("student_sex");
    	String student_class = request.getParameter("student_class");
    	String student_date = request.getParameter("student_date");
    	
    	Student student = new Student();
    	student.setStudent_name(student_name);
    	student.setStudent_number(student_number);
    	student.setStudent_sex(student_sex);
    	student.setStudent_class(student_class);
    	student.setStudent_date(student_date);
    	
    	studentService.insert(student);
    
    	//给前台返回的东西
    	String data = "{\"data\":\"插入成功\"}"; 
        return data; 
    }
    
    @ResponseBody
    @RequestMapping(value="/updateByPrimaryKey", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")  
    public String updateByPrimaryKey(HttpServletRequest request) {
    	
    	String idString = request.getParameter("id");
    	String student_name = request.getParameter("student_name");
    	String student_number = request.getParameter("student_number");
    	String student_sex = request.getParameter("student_sex");
    	String student_class = request.getParameter("student_class");
    	String student_date = request.getParameter("student_date");
    	Integer idInteger = Integer.valueOf(idString);
    	
    	Student student = new Student();
    	student.setId(idInteger);
    	student.setStudent_name(student_name);
    	student.setStudent_number(student_number);
    	student.setStudent_sex(student_sex);
    	student.setStudent_class(student_class);
    	student.setStudent_date(student_date);
    	
    	studentService.updateByPrimaryKey(student);
    	
    	
    	//给前台返回的东西
    	String data = "{\"data\":\"修改成功\"}"; 
        return data; 
    }
    
    @ResponseBody
    @RequestMapping(value="/deleteByPrimaryKey", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")  
    public String deleteByPrimaryKey(HttpServletRequest request) {
    	String  idString = request.getParameter("id");
    	Integer idInteger = Integer.valueOf(idString);
    	
    	studentService.deleteByPrimaryKey(idInteger);
    	String data = "{\"data\":\"删除成功\"}"; 
        return data; 
    }
    
    /*@ResponseBody
    @RequestMapping(value="/deleteByIds", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")  
    public String deleteByIds(HttpServletRequest request) {
    	String ids = request.getParameter("ids");
    	List<String> delstrList = new ArrayList<String>();
    	String[] strs = ids.split(",");
    	for(String str:strs) {
    		delstrList.add(str);
    	}
    	
    	List<Integer> delList = new ArrayList<Integer>();
    	for(String str : strs) {
    		  int i = Integer.parseInt(str);
    		  delList.add(i);
    		}
    	
    	studentService.deleteByIds(delList);
    	String data = "{\"data\":\"删除成功\"}"; 
        return data; 
    }*/
    
}  