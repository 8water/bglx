package com.javen.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

//import com.google.gson.Gson;
import com.javan.util.ObjtoLayJson;
import com.javen.model.Page;
import com.javen.model.Class;
import com.javen.service.ClassService;


@Controller  //返回指定页面  ajax 不能接受到页面的返回 ，所以说
@RequestMapping("/class") 
public class ClassController {  
	
	//private static Gson gson= new Gson();////
	
	private static Logger log=LoggerFactory.getLogger(LoginController.class);
	
	@Autowired  
	private ClassService classService;     
    
    // /user/test?id=1
    @RequestMapping(value="/test", method=RequestMethod.GET)  
    public String test(HttpServletRequest request,Model model){  
        return "back"; 
    }
    
    @ResponseBody
    @RequestMapping(value="/count", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")  
    public String count(HttpServletRequest request) throws Exception{  
    	
    	int count  = classService.count();
    	System.out.println(count);
    	String data = "{\"count\":\""+count+"\"}";
        return data;    
    }
	
    //返回字符串
    @ResponseBody
    @RequestMapping(value="/selectByPrimaryKey", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")  
    public String selectByPrimaryKeyd(HttpServletRequest request) throws Exception{  
    	String  idString = request.getParameter("id");
    	Integer idInteger = Integer.valueOf(idString);
    	Class class1 = classService.selectByPrimaryKey(idInteger);
    	System.out.println(class1.toString());
    	String[] colums = {"id","class_name","class_grade","class_remark","class_date"};
    	String data = ObjtoLayJson.toJson(class1, colums);
    	System.out.println(data);
        return data;    
    }
    
  //返回字符串
    @ResponseBody
    @RequestMapping(value="/selectAll", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")  
    public String selectAll(HttpServletRequest request) throws Exception{  	
    	request.setCharacterEncoding("utf-8");  
    	String pageString = request.getParameter("page");
    	String limitString = request.getParameter("limit");
    	Integer pageInteger = Integer.valueOf(pageString);
    	Integer limitInteger = Integer.valueOf(limitString);	
    	
    	Page page = new Page();
    	page.setOffset((pageInteger-1)*limitInteger);
    	page.setLimit(limitInteger);
    	System.out.println(page.getOffset() + " "+page.getLimit());
    	
    	List<Class> class1 = classService.selectAll(page);
    	String[] colums = {"id","class_name","class_grade","class_remark","class_date","teacher"};
    	//String data = ObjtoLayJson.ListtoJson(class1, colums);
    	//String data = gson.toJson(class1);////
    	String data = "";
    	System.out.println(data);
        return data; 
    }
   
    
    @ResponseBody
    @RequestMapping(value="/insert", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")  
    public String insert(HttpServletRequest request) {
    	
    	String class_name = request.getParameter("class_name");
    	String class_grade = request.getParameter("class_grade");
    	String class_remark = request.getParameter("class_remark");
    	String class_date = request.getParameter("class_date");
    	
    	Class class1 = new Class();
    	class1.setClass_name(class_name);
    	class1.setClass_grade(class_grade);
    	class1.setClass_remark(class_remark);
    	class1.setClass_date(class_date);
    	
    	classService.insert(class1);
    
    	//给前台返回的东西
    	String data = "{\"data\":\"插入成功\"}"; 
        return data; 
    }
    
    @ResponseBody
    @RequestMapping(value="/updateByPrimaryKey", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")  
    public String updateByPrimaryKey(HttpServletRequest request) {
    	
    	String idString = request.getParameter("id");
    	String class_name = request.getParameter("class_name");
    	String class_grade = request.getParameter("class_grade");
    	String class_remark = request.getParameter("class_remark");
    	String class_date = request.getParameter("class_date");
    	Integer idInteger = Integer.valueOf(idString);
    	
    	Class class1 = new Class();
    	class1.setId(idInteger);
    	class1.setClass_name(class_name);
    	class1.setClass_grade(class_grade);
    	class1.setClass_remark(class_remark);
    	class1.setClass_date(class_date);
    	
    	classService.updateByPrimaryKey(class1);
    	
    	
    	//给前台返回的东西
    	String data = "{\"data\":\"修改成功\"}"; 
        return data; 
    }
    
    @ResponseBody
    @RequestMapping(value="/deleteByPrimaryKey", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")  
    public String deleteByPrimaryKey(HttpServletRequest request) {
    	String  idString = request.getParameter("id");
    	Integer idInteger = Integer.valueOf(idString);
    	
    	classService.deleteByPrimaryKey(idInteger);
    	String data = "{\"data\":\"删除成功\"}"; 
        return data; 
    }
    
}  